<?php $__env->startSection('titulo','Form'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1 class="display-1 text-center text-danger">Form</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\GitHub\PW_S181\Practica_3\resources\views/formulario.blade.php ENDPATH**/ ?>