<!-- Modal -->
  <div class="modal fade" id="editar<?php echo e($data->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="staticBackdropLabel">Editar Recuerdo</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
            <form method="POST" action="/recuerdo/<?php echo e($data->id); ?>/confirm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label class="form-label">Titulo:</label>
                    <input type="text" class="form-control" name="txtTitulo" value="<?php echo e($data->titulo); ?>">
                    <?php if($errors->first('txtTitulo')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($errors->first('txtTitulo')); ?>

                      </div>
                    <?php endif; ?>
                </div>

                <div class="mb-3">
                    <label class="form-label">Recuerdo:</label> 
                    <textarea class="form-control" style="height: 100px" name="txtRecuerdo" ><?php echo e($data->recuerdo); ?></textarea>
                    <?php if($errors->first('txtRecuerdo')): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($errors->first('txtRecuerdo')); ?>

                      </div>
                    <?php endif; ?>
                </div>
        </div>
        
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          <button type="submit" class="btn btn-info">Guardar cambios</button>
        </form>
        </div>
      </div>
    </div>
  </div>

  <!--Modal eliminar-->
  <div class="modal fade" id="eliminar<?php echo e($data->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="staticBackdropLabel">Eliminar Recuerdo</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
            <form method="POST" action="/recuerdo/<?php echo e($data->id); ?>/delete">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                <div class="card mb-2">
                  <h5 class="card-header"><?php echo e($data->fecha); ?></h5>
                  <div class="card-body">
                    <div class="border p-1 mb-3">
                      <h5 class="card-title fw-bold"><?php echo e($data->titulo); ?></h5>
                      <p class="card-text"><?php echo e($data->recuerdo); ?></p>
                    </div>
                  </div>
              </div>
        </div>
        
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          <button type="submit" class="btn btn-danger">Eliminar</button>
        </form>
        </div>
      </div>
    </div>
  </div><?php /**PATH C:\GitHub\PW_S181\Practica_Laravel\resources\views/partials/modal.blade.php ENDPATH**/ ?>