<p class="bg-blue-800 p-4 text-lg text-red-100">
    <?php echo e($message); ?> - <?php echo e($date); ?>

  </p>
  <?php /**PATH C:\GitHub\PW_S181\Practica_3\resources\views/components/message.blade.php ENDPATH**/ ?>