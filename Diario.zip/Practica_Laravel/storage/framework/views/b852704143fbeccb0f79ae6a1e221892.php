<?php $__env->startSection('titulo','Recuerdos'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1 class="display-1 text-center text-primary">Memories</h1>
    <?php if(session()->has('Confirmacion')): ?>
        <script>
          Swal.fire({
          text: "<?php echo e(session('Confirmacion')); ?>",
          icon: "success"
          });
        </script>           

        <?php endif; ?>
    <div class="container">

        <?php $__currentLoopData = $consR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-2">
            <h5 class="card-header"><?php echo e($data->fecha); ?></h5>
            <div class="card-body">
              <div class="border p-1 mb-3">
                <h5 class="card-title fw-bold"><?php echo e($data->titulo); ?></h5>
                <p class="card-text"><?php echo e($data->recuerdo); ?></p>
              </div>
              <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#editar<?php echo e($data->id); ?>">
                Editar
              </button>
              <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#eliminar<?php echo e($data->id); ?>">
                Eliminar
              </button>
            </div>
        </div>
        <?php echo $__env->make('partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo $__env->make('partials.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\GitHub\PW_S181\Practica_Laravel\resources\views/recuerdos.blade.php ENDPATH**/ ?>