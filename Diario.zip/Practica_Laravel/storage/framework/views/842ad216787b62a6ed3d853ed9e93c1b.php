<?php $__env->startSection('titulo','Home'); ?>
<?php $__env->startSection('contenido'); ?>
    <h1 class="display-1 text-center text-info">Home</h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\GitHub\PW_S181\Practica_Laravel\resources\views/welcome.blade.php ENDPATH**/ ?>