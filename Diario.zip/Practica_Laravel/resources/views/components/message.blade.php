<p class="bg-blue-800 p-4 text-lg text-red-100">
    {{ $message }} - {{ $date }}
  </p>
  