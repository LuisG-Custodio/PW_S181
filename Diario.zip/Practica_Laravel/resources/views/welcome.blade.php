@extends('layouts.plantilla')
@section('titulo','Home')
@section('contenido')
    <h1 class="display-1 text-center text-info">Home</h1>

@endsection

